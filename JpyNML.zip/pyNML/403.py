import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "403"
trainIDNumber = "2043"
trainIDType = "emu_403"

#per train
trainLiveryList = [
    "initial",
    "joban",
    "kyushu",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto"
    ]

spriteYearOverride = {
  #"kyushu": {
  #  "1995" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  #}
}

trainPantoPosVehID = {
  "initial" : {"default"},
  "joban" : {"default"},
  "kyushu" : {"default"},
}

trainPantoPosChain = {
  "initial": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "joban": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "kyushu": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)