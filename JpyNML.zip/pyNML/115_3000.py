import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "1153000"
trainIDNumber = "2045"
trainIDType = "emu_1153000"

#per train
trainLiveryList = [
    "setouchi_1",
    "hiroshima_1",
    "jrw_regional_1",
    "jrw_refurb_1",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto"
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "setouchi_1" : {"0..4","default"},
  "hiroshima_1" : {"0..4","default"},
  "jrw_regional_1" : {"0..4","default"},
  "jrw_refurb_1" : {"0..4","default"},
}

trainPantoPosChain = {
  "setouchi_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "hiroshima_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_regional_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_refurb_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)