import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "415"
trainIDNumber = "2041"
trainIDType = "emu_415"

#per train
trainLiveryList = [
    "initial",
    "joban",
    "kyushu",
    "jrw_regional_1",
    "jrw_regional_2",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto"
    ]

spriteYearOverride = {
  "kyushu": {
    "1995" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
  "jrw_regional_1": {
    "1995" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
}

trainPantoPosVehID = {
  "initial" : {"default"},
  "joban" : {"default"},
  "kyushu" : {"default"},
  "jrw_regional_1" : {"default"},
  "jrw_regional_2" : {"default"},
}

trainPantoPosChain = {
  "initial": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "joban": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "kyushu": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "jrw_regional_1": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "jrw_regional_2": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)