import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "323"
trainIDNumber = "2057"
trainIDType = "emu_323"

#per train
trainLiveryList = [
    "std",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_dpanto",
    "mid_spanto",
    "mid_gr",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "std" : {"0..1","2..3","4","default"},
}

trainPantoPosChain = {

  "std": {
    "0..1" :  {
        "default" : "mid",
      },
    "2..3" :  {
        "0" :  "mid_dpanto",
        "default" : "mid",
      },
    "4" :  {
        "0" :  "mid_dpanto",
        "2" :  "mid_spanto",       
        "default" : "mid",
      },
    "default" :  {
        "0" :  "mid_dpanto",
        "2" :  "mid_gr",       
        "3" :  "mid_spanto",
        "default" : "mid",
        "%" : "8",
      }, 
    },


  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)