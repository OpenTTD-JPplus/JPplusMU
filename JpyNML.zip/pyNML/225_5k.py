import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "225_5000"
trainIDNumber = "2054"
trainIDType = "emu_225_5000"

#per train
trainLiveryList = [
    "5000type",
    "5100type_nw",
    "5100type_ww",
    "6000type",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    ]

spriteYearOverride = {
    "5000type": {
    "2015" : {"front_wing","back_wing",},
    },
    "6000type": {
    "2015" : {"front_wing","back_wing",},
    },
}

trainPantoPosVehID = {
  "5000type" : {"0..2","3..4","default"},
  "5100type_nw" : {"0..2","3..4","default"},
  "5100type_ww" : {"0..2","3..4","default"},
  "6000type" : {"0..2","3..4","default"},
}

trainPantoPosChain = {

  "5000type": {
    "0..2" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "3..4" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "8",
      }, 
    },
  "5100type_nw": {
    "0..2" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "3..4" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "8",
      }, 
    },
      "5100type_ww": {
    "0..2" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "3..4" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "8",
      }, 
    },
    "6000type": {
    "0..2" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "3..4" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "8",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)