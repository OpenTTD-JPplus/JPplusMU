import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "383"
trainIDNumber = "2058"
trainIDType = "emu_383"

#per train
trainLiveryList = [
    "std",
    "view",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "std" : {"default"},
  "view" : {"default"},
}

trainPantoPosChain = {

  "std": {
    "default" :  {
        "0" :  "mid_panto",
        "default" : "mid",
        "%" : "2",
      }, 
    },
  "view": {
    "default" :  {
        "0" :  "mid_panto",
        "default" : "mid",
        "%" : "2",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)