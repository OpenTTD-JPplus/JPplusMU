import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "103"
trainIDNumber = "2029"
trainIDType = "emu_103"

#per train
trainLiveryList = [
    "orange_lowcab_1",
    "orange_highcab_1",
    "orange_lowcab_2",
    "orange_highcab_2",
    "green_lowcab_1",
    "green_highcab_1",
    "green_lowcab_2",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto"
    ]

spriteYearOverride = {
  "orange_lowcab_1": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
    "1986" : {"front_sk","back_sk","mid_sk","mid_panto_sk","back_panto_sk"},
    "1996" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
  "orange_highcab_1": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
    "1986" : {"front_sk","back_sk","mid_sk","mid_panto_sk","back_panto_sk"},
    "1996" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
  "orange_lowcab_2": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
  },
  "orange_highcab_2": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
  },
  "green_lowcab_1": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
    "1986" : {"front_sk","back_sk","mid_sk","mid_panto_sk","back_panto_sk"},
    "1996" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
  "green_highcab_1": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
    "1986" : {"front_sk","back_sk","mid_sk","mid_panto_sk","back_panto_sk"},
    "1996" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
  "green_lowcab_2": {
    "1973" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
    "1990" : {"front_sk","back_sk","mid_sk","mid_panto_sk","back_panto_sk"},
    "1996" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  },
}

trainPantoPosVehID = {
  "orange_lowcab_1" : {"0..1","default"},
  "orange_highcab_1" : {"0..1","default"},
  "orange_lowcab_2" : {"0..1","default"},
  "orange_highcab_2" : {"0..1","default"},
  "green_lowcab_1" : {"0..1","default"},
  "green_highcab_1" : {"0..1","default"},
  "green_lowcab_2" : {"0..1","default"},
}

trainPantoPosChain = {

  "orange_lowcab_1": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "orange_highcab_1": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "orange_lowcab_2": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "orange_highcab_2": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "green_lowcab_1": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "green_highcab_1": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "green_lowcab_2": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)