import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "651"
trainIDNumber = "2050"
trainIDType = "emu_651"

#per train
trainLiveryList = [
    "hitachi",
    "akagi",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_gr",
    "mid_a_panto",
    "mid_b_panto",
    "back_panto",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "hitachi" : {"0..2","default"},
  "akagi" : {"0..2","default"},
}

trainPantoPosChain = {

  "hitachi": {
    "0..2" :  {
        "0" : "mid_b_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_a_panto",
        "2" : "mid_gr",
        "3" : "mid_b_panto",
        "default" : "mid",
        "%" : "7",
      }, 
    },
  "akagi": {
    "0..2" :  {
        "0" : "mid_b_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_a_panto",
        "2" : "mid_gr",
        "3" : "mid_b_panto",
        "default" : "mid",
        "%" : "7",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)