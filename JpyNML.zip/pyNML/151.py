import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "151"
trainIDNumber = "2031"
trainIDType = "emu_151"

#per train
trainLiveryList = [
    "151_normal",
    "181_normal",
    "181_niigata",
    ]

spriteList = [
    "front",
    "front_gr",
    "back",
    "mid",
    "mid_panto",
    "mid_gr",
    "mid_gr_panto",
    "mid_buffet1",
    "mid_buffet2",
    "back_panto",
    ]

spriteYearOverride = {
  "181_normal": {
    "1978" : {"mid_gr_new","mid_gr_panto_new"},
  },
  "181_niigata": {
    "1978" : {"mid_gr2","mid_gr_panto2"},
  },
}

trainPantoPosVehID = {
  "151_normal" : {"default"},
  "181_normal" : {"default"},
  "181_niigata" : {"default"},
}

trainPantoPosChain = {
  "151_normal": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "181_normal": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "181_niigata": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)
