import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "80"
trainIDNumber = "1515"
trainIDType = "dmu_80"

#per train
trainLiveryList = [
    "kiha81",
    "kiha82",
    ]

spriteList = [
    "front81",
    "back81",
    "front82",
    "back82",
    "mid",
    "mid_gr",
    "mid_bft",
    ]

spriteYearOverride = {
  "kiha81": {
    "1969" : {"mid_gr_new"},
  },
  "kiha82": {
    "1969" : {"mid_gr_new"},
  },
}

trainPantoPosVehID = {
  "kiha81" : {"0..1","2","3..5","6","7","default"},
  "kiha82" : {"0..1","2","3..5","6","7..10","default"},
}

trainPantoPosChain = {
  "kiha81": {
    "0..1" :  {
        "default" : "mid",
      },
      "2" :  {
        "0" : "mid_gr",
        "default" : "mid",
      }, 
      "3..5" :  {
        "0" : "mid_gr",
        "1" : "mid_bft",
        "default" : "mid",
      }, 
      "6" :  {
        "0" : "mid_gr",
        "1" : "mid_gr",        
        "2" : "mid_bft",
        "default" : "mid",
      }, 
      "7" :  {
        "1" : "front82",        
        "2" : "mid_gr",
        "3" : "mid_bft",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_gr",
        "1" : "mid_gr",        
        "2" : "mid_bft",
        "default" : "mid",
      }, 
    },
  "kiha82": {
    "0..1" :  {
        "default" : "mid",
      },
      "2" :  {
        "0" : "mid_gr",
        "default" : "mid",
      }, 
      "3..5" :  {
        "0" : "mid_gr",
        "1" : "mid_bft",
        "default" : "mid",
      }, 
      "6" :  {
        "0" : "mid_gr",
        "1" : "mid_gr",        
        "2" : "mid_bft",
        "default" : "mid",
      },  
    "7..10" :  {
        "2" : "front82",
        "3" : "mid_gr",        
        "4" : "mid_bft",
        "8" : "back82",
        "default" : "mid",
      },
      "default" :  {
        "2" : "front82",
        "3" : "mid_gr",        
        "4" : "mid_bft",
        "8" : "back82",
        "9" : "mid_gr",
        "default" : "mid",
      },
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)