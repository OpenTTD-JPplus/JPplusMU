def speed_check(speed):
    x=(speed-120)//10
    if speed <120:
        return ("ok")
    elif x<10:
        return (x)
    else:
        return ("license suspended")


test1 = speed_check(98)
test2 = speed_check(144)
test3 = speed_check(250)

if test1=="ok" and test2==2 and test3=="license suspended":
    print("correct")
else:
    print("not correct")