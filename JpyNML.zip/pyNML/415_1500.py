import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "4151500"
trainIDNumber = "2044"
trainIDType = "emu_4151500"

#per train
trainLiveryList = [
    "joban1",
    "joban2",
    "joban3",
    "kyushu",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto"
    ]

spriteYearOverride = {
  "kyushu": {
    "1997" : {"front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"},
  }
}

trainPantoPosVehID = {
  "joban1" : {"default"},
  "joban2" : {"default"},
  "joban3" : {"default"},
  "kyushu" : {"default"},
}

trainPantoPosChain = {
  "joban1": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "joban2": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "joban3": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "kyushu": {
    "default" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)