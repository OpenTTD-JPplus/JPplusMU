import JpyNML as JpyNML

trainTypePrefix = "209"
trainIDNumber = "2323"
trainIDType = "emu_209"

#per train
trainLiveryList = [
    "kt_0",
    "nannbu"
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_hd",
    "mid_panto",
    "back_panto"
    ]

trainPantoPosVehID = {
  "kt_0" : {"default", "5", "0..4"},
  "nannbu" : {"0..4", "default"}
}

trainPantoPosChain = {
  "kt_0": {
    "0..4" : {
        "0" : "mid_panto",
        "4" : "mid_panto",
        "default" : "mid",
      }, 
    "5" : {
        "0" : "mid_panto",
        "5" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "8" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "nannbu": {
    "0..4" : {
        "0" : "mid_panto",
        "4" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "8" : "mid_panto",
        "default" : "mid",
      }, 
    }
}

#
#
#

JpyNML.JpyNML_Build_All(trainTypePrefix,trainTypePrefix,trainIDType,trainLiveryList,spriteList,trainPantoPosVehID,trainPantoPosChain)