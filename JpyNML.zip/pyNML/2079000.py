import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "207900"
trainIDNumber = "2049"
trainIDType = "emu_207900"

#per train
trainLiveryList = [
    "std",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "std" : {"0..1","default"},
}

trainPantoPosChain = {

  "std": {
    "0..1" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "4" : "mid_panto",
        "7" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)