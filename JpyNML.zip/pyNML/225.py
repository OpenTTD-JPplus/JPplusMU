import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "225_0"
trainIDNumber = "2053"
trainIDType = "emu_225_0"

#per train
trainLiveryList = [
    "0type",
    "100type",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    ]

spriteYearOverride = {
    "0type": {
    "2015" : {"front_wing","back_wing",},
    },
}

trainPantoPosVehID = {
  "0type" : {"0..2","3..4","default"},
  "100type" : {"0..2","3..4","default"},
}

trainPantoPosChain = {

  "0type": {
    "0..2" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "3..4" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "8",
      }, 
    },
  "100type": {
    "0..2" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "3..4" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "8",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)