def Build_Sprites_Bamito (trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain):
  trainSpritePrefix = "spriteset_"+trainTypePrefix

  print("/*---GFX: Spritesets---*/")

  for trainLivery in trainLiveryList:
    print("//"+trainLivery+" Spriteset")
    for spriteID in spriteList:
      print("spriteset("+trainSpritePrefix+"_"+spriteID+"_"+trainLivery+",     \"gfx/OTHER/mucar.png\")      {tmpl_std(0, 0)}")
    print("")
    for spriteID in spriteList:
      print("spriteset("+trainSpritePrefix+"_rev_"+spriteID+"_"+trainLivery+",     \"gfx/OTHER/mucar.png\")      {tmpl_std(0, 0)}")
    print("")
    for spriteID in spriteList:
      print("spriteset("+trainSpritePrefix+"_revflip_"+spriteID+"_"+trainLivery+",     \"gfx/OTHER/mucar.png\")      {tmpl_std(0, 0)}")
    print("")
    for spriteID in spriteList:
      if "front" in spriteID:
        templateSet = "tmpl_std(0, 1)"
      elif "back" in spriteID:
        templateSet = "tmpl_std_rev(0, 26)"
      elif "mid" in spriteID:
        templateSet = "tmpl_std(0, 1)"
      else:
        templateSet = "tmpl_std(0, 1)"
      print("alternative_sprites("+trainSpritePrefix+"_"+spriteID+"_"+trainLivery+",     ZOOM_LEVEL_NORMAL, BIT_DEPTH_32BPP,     \"gfx/COMPANY_REF/"+trainIDType.replace("_", "")+"/LIVERY_REF/"+trainTypePrefix+"-REF_LV-REF_CR.png\")      {"+templateSet+"}")
    print("")
    for spriteID in spriteList:
      if "front" in spriteID:
        templateSet = "tmpl_std_rev(0, 26)"
      elif "back" in spriteID:
        templateSet = "tmpl_std_rev(0, 1)"
      elif "mid" in spriteID:
        templateSet = "tmpl_std(0, 1)"
      else:
        templateSet = "tmpl_std(0, 1)"
      print("alternative_sprites("+trainSpritePrefix+"_rev_"+spriteID+"_"+trainLivery+",     ZOOM_LEVEL_NORMAL, BIT_DEPTH_32BPP,     \"gfx/COMPANY_REF/"+trainIDType.replace("_", "")+"/LIVERY_REF/"+trainTypePrefix+"-REF_LV-REF_CR.png\")      {"+templateSet+"}")
    print("")
    for spriteID in spriteList:
      if "front" in spriteID:
        templateSet = "tmpl_std(0, 26)"
      elif "back" in spriteID:
        templateSet = "tmpl_std(0, 1)"
      elif "mid" in spriteID:
        templateSet = "tmpl_std_rev(0, 1)"
      else:
        templateSet = "tmpl_std_rev(0, 1)"
      print("alternative_sprites("+trainSpritePrefix+"_revflip_"+spriteID+"_"+trainLivery+",     ZOOM_LEVEL_NORMAL, BIT_DEPTH_32BPP,     \"gfx/COMPANY_REF/"+trainIDType.replace("_", "")+"/LIVERY_REF/"+trainTypePrefix+"-REF_LV-REF_CR.png\")      {"+templateSet+"}")
    print("")

    if trainLivery in spriteYearOverride.keys():
      print("//"+trainLivery+" OVERRIDE Spriteset")
      for x in spriteYearOverride[trainLivery]:
        for y in spriteYearOverride[trainLivery][x]:
          print("spriteset("+trainSpritePrefix+"_"+y+"_"+trainLivery+",     \"gfx/OTHER/mucar.png\")      {tmpl_std(0, 0)}")
      print("")
      for x in spriteYearOverride[trainLivery]:
        for y in spriteYearOverride[trainLivery][x]:
          print("spriteset("+trainSpritePrefix+"_rev_"+y+"_"+trainLivery+",     \"gfx/OTHER/mucar.png\")      {tmpl_std(0, 0)}")
      print("")
      for x in spriteYearOverride[trainLivery]:
        for y in spriteYearOverride[trainLivery][x]:
          print("spriteset("+trainSpritePrefix+"_revflip_"+y+"_"+trainLivery+",     \"gfx/OTHER/mucar.png\")      {tmpl_std(0, 0)}")
      print("")
      for x in spriteYearOverride[trainLivery]:
        for y in spriteYearOverride[trainLivery][x]:
          if "front" in y:
            templateSet = "tmpl_std(0, 1)"
          elif "back" in y:
            templateSet = "tmpl_std_rev(0, 26)"
          elif "mid" in y:
            templateSet = "tmpl_std(0, 1)"
          else:
            templateSet = "tmpl_std(0, 1)"
          print("alternative_sprites("+trainSpritePrefix+"_"+y+"_"+trainLivery+",     ZOOM_LEVEL_NORMAL, BIT_DEPTH_32BPP,     \"gfx/COMPANY_REF/"+trainIDType.replace("_", "")+"/LIVERY_REF/"+trainTypePrefix+"-REF_LV-REF_CR.png\")      {"+templateSet+"}")
      print("")
      for x in spriteYearOverride[trainLivery]:
        for y in spriteYearOverride[trainLivery][x]:
          if "front" in y:
            templateSet = "tmpl_std_rev(0, 26)"
          elif "back" in y:
            templateSet = "tmpl_std_rev(0, 1)"
          elif "mid" in y:
            templateSet = "tmpl_std(0, 1)"
          else:
            templateSet = "tmpl_std(0, 1)"
          print("alternative_sprites("+trainSpritePrefix+"_rev_"+y+"_"+trainLivery+",     ZOOM_LEVEL_NORMAL, BIT_DEPTH_32BPP,     \"gfx/COMPANY_REF/"+trainIDType.replace("_", "")+"/LIVERY_REF/"+trainTypePrefix+"-REF_LV-REF_CR.png\")      {"+templateSet+"}")
      print("")
      for x in spriteYearOverride[trainLivery]:
        for y in spriteYearOverride[trainLivery][x]:
          if "front" in y:
            templateSet = "tmpl_std(0, 26)"
          elif "back" in y:
            templateSet = "tmpl_std(0, 1)"
          elif "mid" in y:
            templateSet = "tmpl_std_rev(0, 1)"
          else:
            templateSet = "tmpl_std_rev(0, 1)"
          print("alternative_sprites("+trainSpritePrefix+"_revflip_"+y+"_"+trainLivery+",     ZOOM_LEVEL_NORMAL, BIT_DEPTH_32BPP,     \"gfx/COMPANY_REF/"+trainIDType.replace("_", "")+"/LIVERY_REF/"+trainTypePrefix+"-REF_LV-REF_CR.png\")      {"+templateSet+"}")
      print("")

  print("/*---END OF SECTION---*/")