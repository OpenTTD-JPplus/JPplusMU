import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "207"
trainIDNumber = "2030"
trainIDType = "emu_201"

#per train
trainLiveryList = [
    "orange_std",
    "orange_chou",
    "yellow_chousobu",
    "blue_keiyo",
    "blue_keihanshin",
    "green_jrw",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto",
    ]

spriteYearOverride = {
  "orange_std": {
    "1980" : {"front_ns","back_ns","back_panto_ns"},
    "1992" : {"front_sk","back_sk","back_panto_sk"},
    "2003" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
  },
  "orange_chou": {
    "1980" : {"front_ns","back_ns","back_panto_ns"},
    "1992" : {"front_sk","back_sk","back_panto_sk"},
    "2000" : {"mid_panto_sp","back_panto_sp"},
  },
  "yellow_chousobu": {
    "1992" : {"front_sk","back_sk"},
  },
  "blue_keiyo": {
    "2007" : {"mid_panto_sp","back_panto_sp"},
  },
  "blue_keihanshin": {
    "1992" : {"front_sk","back_sk","back_panto_sk"},
    "2003" : {"front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"},
  },
}

trainPantoPosVehID = {
  "orange_std" : {"0..4","default"},
  "orange_chou" : {"0..4","default"},
  "yellow_chousobu" : {"0..4","default"},
  "blue_keiyo" : {"0..4","default"},
  "blue_keihanshin" : {"0..4","default"},
  "green_jrw" : {"0..4","default"},
}

trainPantoPosChain = {

  "orange_std": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "orange_chou": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "yellow_chousobu": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "blue_keiyo": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "blue_keihanshin": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "green_jrw": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)