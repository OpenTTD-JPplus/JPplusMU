trainTypePrefix = "209"
trainSpritePrefix = "spriteset_"+trainTypePrefix

trainIDNumber = "2323"
trainIDType = "emu_209"

#per train
trainLiveryList = [
    "kt_0",
    "nannbu"
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_hd",
    "mid_panto",
    "back_panto"
    ]

trainPantoPosVehID = {
  "kt_0" : {"default", "5", "0..4"},
  "nannbu" : {"0..4", "default"}
}

trainPantoPosChain = {
  "kt_0": {
    "0..4" : {
        "0" : "mid_panto",
        "4" : "mid_panto",
        "default" : "mid",
      }, 
    "5" : {
        "0" : "mid_panto",
        "5" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "8" : "mid_panto",
        "default" : "mid",
      }, 
    },
  "nannbu": {
    "0..4" : {
        "0" : "mid_panto",
        "4" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "8" : "mid_panto",
        "default" : "mid",
      }, 
    }
}

#for id, info in trainPantoPos.items():
#    print(id)
#    for key in info:
#        print(key + ':', info[key])



#seperate for pantograph graphics section
print("/*---GFX: Pantograph Positions---*/")
#creates the sub pantograph switches
for trainLivery in trainLiveryList:
  swkey = 0
  for x in sorted(trainPantoPosVehID[trainLivery]):
    swkey += 1
    print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_pantograph_pos_"+trainLivery+"_sw"+str(swkey)+", position_in_vehid_chain){")
    for y in sorted(trainPantoPosChain[trainLivery][x]):
      print(" "+y+" : "+trainSpritePrefix+"_"+trainPantoPosChain[trainLivery][x][y]+"_"+trainLivery+";")
    print ("}")


    
#creates the main pantograph switch
for trainLivery in trainLiveryList:
  print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_pantograph_pos_"+trainLivery+", num_vehs_in_vehid_chain){")
  swkey = 0
  for x in sorted(trainPantoPosVehID[trainLivery]):
    swkey += 1
    print ("  "+x+" : sw_"+trainTypePrefix+"_gfx_pantograph_pos_"+trainLivery+"_sw"+str(swkey)+";")
  print ("}")
#seperate for pantograph graphics section
print("/*---END OF SECTION---*/")






#seperate for reversing section
print("/*---GFX: Train Reversing Switches---*/")
#create the by livery reversed gfx
for spriteID in spriteList:
  print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_"+spriteID+"_livery, [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 0, 0x0000FFFF, 0xF2]]){")
  swkey = 0
  for trainLivery in trainLiveryList:
    print (str(swkey)+" : "+trainSpritePrefix+"_rev_"+spriteID+"_"+trainLivery+";")
    swkey += 1
  print("}")

  print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_revflip_"+spriteID+"_livery, [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 0, 0x0000FFFF, 0xF2]]){")
  swkey = 0
  for trainLivery in trainLiveryList:
    print (str(swkey)+" : "+trainSpritePrefix+"_revflip_"+spriteID+"_"+trainLivery+";")
    swkey += 1
  print("}")


#create the reversed flipcheckers
for spriteID in spriteList:
  print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_"+spriteID+"_flippedcheck, vehicle_is_flipped) {")
  print ("  1 : sw_"+trainTypePrefix+"_gfx_rev_"+spriteID+"_livery;")
  print ("  default : sw_"+trainTypePrefix+"_gfx_revflip_"+spriteID+"_livery;")
  print ("}")


#creates the sub pantograph switches in reverse
for trainLivery in trainLiveryList:
  swkey = 0
  for x in sorted(trainPantoPosVehID[trainLivery]):
    swkey += 1
    print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_pantograph_pos_"+trainLivery+"_sw"+str(swkey)+", [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 0, 0x000000FF, 0x41]]){){")
    for y in sorted(trainPantoPosChain[trainLivery][x]):
      print(" "+y+" : sw_"+trainTypePrefix+"_gfx_rev_"+trainPantoPosChain[trainLivery][x][y]+"_flippedcheck;")
    print ("}")

#creates the main pantograph switch in reverse
for trainLivery in trainLiveryList:
  print ("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_pantograph_pos_"+trainLivery+", [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 16, 0x000000FF, 0x41]]){")
  swkey = 0
  for x in sorted(trainPantoPosVehID[trainLivery]):
    swkey += 1
    print ("  "+x+" : sw_"+trainTypePrefix+"_gfx_rev_pantograph_pos_"+trainLivery+"_sw"+str(swkey)+";")
  print ("}")

#creates the livery sorter for reversed trains
print("switch(FEAT_TRAINS,SELF, sw_"+trainTypePrefix+"_gfx_rev_pantograph_pos, [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 0, 0x0000FFFF, 0xF2]]){")
swkey = 0
for trainLivery in trainLiveryList:
  print (str(swkey)+" : sw"+trainTypePrefix+"_gfx_rev_pantograph_pos_"+trainLivery+";")
  swkey += 1
print("}")


print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_back_pantocheck, [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 0, 0x000000FF, 0x41]]){")
print(" 0 : sw_"+trainTypePrefix+"_gfx_rev_back_flippedcheck;")
print(" default : sw_"+trainTypePrefix+"_gfx_rev_back_panto_flippedcheck;")
print("}")

print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_frontback_nomucars,")
print("[STORE_TEMP(position_in_consist_from_end-position_in_consist-1, 0x10F), var[0x61, 0, 0x000000FF, 0x41]%2]){")
print(" 1 : sw_"+trainTypePrefix+"_gfx_rev_front_flippedcheck;")
print(" 0 : sw_"+trainTypePrefix+"_gfx_rev_back_pantocheck;")
print("}")

print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_frontback_aftermucars,")
print("[STORE_TEMP(position_in_consist_from_end-position_in_consist-1, 0x10F), var[0x61, 0, 0x000000FF, 0x41]%2]){")
print(" 1 : sw_"+trainTypePrefix+"_gfx_rev_back_pantocheck;")
print(" 0 : sw_"+trainTypePrefix+"_gfx_rev_front_flippedcheck;")
print("}")

print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_frontback_mucarcheck,")
print("[STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F),STORE_TEMP(var[0x61, 0, 0x000000FF, 0x41],0),")
print("STORE_TEMP((position_in_consist_from_end-position_in_consist-1)-LOAD_TEMP(0), 0x10F),")
print("var[0x61, 0, 0x0000FFFF, 0xC6]]){")
print(" 1000 : sw_"+trainTypePrefix+"_gfx_rev_frontback_aftermucars;")
print(" default : sw_"+trainTypePrefix+"_gfx_rev_frontback_nomucars;")
print("}")

print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_frontback_sameid,")
print("[STORE_TEMP(position_in_consist_from_end-position_in_consist+1, 0x10F), var[0x61, 0, 0x0000FFFF, 0xC6]]){")
print(" "+trainIDNumber+" : sw_"+trainTypePrefix+"_gfx_rev_frontback_mucarcheck;")
print(" 1000 : sw_"+trainTypePrefix+"_gfx_rev_front_flippedcheck;")
print(" default : sw_"+trainTypePrefix+"_gfx_rev_back_pantocheck;")
print("}")

print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_frontback,")
print("[STORE_TEMP(position_in_consist_from_end-position_in_consist-1, 0x10F), var[0x61, 0, 0x0000FFFF, 0xC6]]){")
print(" "+trainIDNumber+" : sw_"+trainTypePrefix+"_gfx_rev_frontback_sameid;")
print(" 1000 : sw_"+trainTypePrefix+"_gfx_rev_back_pantocheck;")
print(" default : sw_"+trainTypePrefix+"_gfx_rev_front_flippedcheck;")
print("}")

print("switch(FEAT_TRAINS, SELF, sw_"+trainTypePrefix+"_gfx_rev_idcheck, [STORE_TEMP(position_in_consist_from_end-position_in_consist, 0x10F), var[0x61, 0, 0x0000FFFF, 0xC6]]){")
print(" 1000 : sw_"+trainTypePrefix+"_gfx_rev_pantograph_pos;")
print(" "+trainIDNumber+" : sw_"+trainTypePrefix+"_gfx_rev_frontback;")
print("}")
#seperate for reversing section
print("/*---END OF SECTION---*/")