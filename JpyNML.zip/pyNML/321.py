import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "321"
trainIDNumber = "2056"
trainIDType = "emu_321"

#per train
trainLiveryList = [
    "std",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "std" : {"0..1","default"},
}

trainPantoPosChain = {

  "std": {
    "0..1" :  {
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "7",
      }, 
    },


  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)