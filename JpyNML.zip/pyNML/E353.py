import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "E353"
trainIDNumber = "2051"
trainIDType = "emu_E353"

#per train
trainLiveryList = [
    "azusa",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_gr",
    "mid_singlepanto",
    "mid_dualpanto_a",
    "mid_dualpanto_b",
    "back_panto",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "azusa" : {"0..3","default"},
}

trainPantoPosChain = {

  "azusa": {
    "0..3" :  {
        "0" : "mid_dualpanto_a",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_dualpanto_b",
        "2" : "mid_singlepanto",
        "4" : "mid_gr",
        "5" : "mid_singlepanto",
        "default" : "mid",
        "%" : "9",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)