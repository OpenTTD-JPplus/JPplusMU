import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "373"
trainIDNumber = "2059"
trainIDType = "emu_373"

#per train
trainLiveryList = [
    "std",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "std" : {"default"},
  "view" : {"default"},
}

trainPantoPosChain = {

  "std": {
    "default" :  {
        "default" : "mid",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)