import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "227"
trainIDNumber = "2055"
trainIDType = "emu_227"

#per train
trainLiveryList = [
    "0type",
    "1000type",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "0type" : {"default"},
  "1000type" : {"default"},
}

trainPantoPosChain = {

  "0type": {
    "default" :  {
        "default" : "mid",
      }, 
    },
  "1000type": {
    "default" :  {
        "default" : "mid",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)