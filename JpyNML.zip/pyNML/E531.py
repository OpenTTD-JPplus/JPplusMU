import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "E531"
trainIDNumber = "2052"
trainIDType = "emu_E531"

#per train
trainLiveryList = [
    "joban_a",
    "joban_b",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_gr",
    "mid_panto",
    "back_2",
    "back_panto",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "joban_a" : {"0..1","1..5","default"},
  "joban_b" : {"0..1","1..5","default"},
}

trainPantoPosChain = {

  "joban_a": {
    "0..1" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "1..5" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },
  "joban_b": {
    "0..1" :  {
        "0" : "mid_panto",
        "default" : "mid",
      }, 
    "1..5" :  {
        "1" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "1" : "mid_panto",
        "6" : "mid_panto",
        "default" : "mid",
        "%" : "10",
      }, 
    },

  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)