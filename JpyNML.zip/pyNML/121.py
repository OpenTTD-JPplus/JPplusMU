import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "121"
trainIDNumber = "2046"
trainIDType = "emu_121"

#per train
trainLiveryList = [
    "jnr_red",
    "jrs_blue",
    "jrs_redfront",
    "jrs_7200"
    ]

spriteList = [
    "front",
    "back",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "jnr_red" : {"default"},
  "jrs_blue" : {"default"},
  "jrs_redfront" : {"default"},
  "jrs_7200" : {"default"},
}

trainPantoPosChain = {
  "jnr_red": {
    "default" :  {
      }, 
    },
  "jrs_blue": {
    "default" :  {
      }, 
    },
  "jrs_redfront": {
    "default" :  {
      }, 
    },
  "jrs_7200": {
    "default" :  {
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)