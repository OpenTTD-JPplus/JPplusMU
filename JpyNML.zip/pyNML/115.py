import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "115"
trainIDNumber = "2025"
trainIDType = "emu_115"

#per train
trainLiveryList = [
    "shonan_1",
    "shonan_2",
    "yamasuka_1",
    "yamasuka_2",
    "minobu_1",
    "niigata_1",
    "niigata_2",
    "niigata_3",
    "niigata_4",
    "yahiko_1",
    "yahiko_2",
    "nagano_1",
    "nagano_2",
    "fukuchiyama_1",
    "fukuchiyama_2",
    "setouchi_1",
    #"hiroshima_1",
    "jrw_regional_1",
    "jrw_regional_2",
    "jrw_regional_3",
    "jrw_refurb_1",
    "jrw_refurb_2",
    "jrw_refurb_3",
    "shinano",    
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_panto",
    "back_panto"
    ]

spriteYearOverride = {
  "shonan_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "yamasuka_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "minobu_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
  },
  "niigata_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "niigata_2": {
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "niigata_3": {
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "yahiko_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "yahiko_2": {
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "nagano_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
  },
  "nagano_2": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
    "1997" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },
  "fukuchiyama_1": {
    "1973" : ["front_ac","back_ac","mid_ac","mid_panto_ac","back_panto_ac"],
  },
  "setouchi_1": {
    "2009" : ["front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"],
  },
  #"hiroshima_1": {
  #  "2009" : ["front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"],
  #},
  #"jrw_refurb_1": {
  #  "2009" : ["front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"],
  #},
  "jrw_refurb_2": {
    "2009" : ["front_nv","back_nv","mid_nv","mid_panto_nv","back_panto_nv"],
  },
  "shinano": {
    "2009" : ["back_panto_ac_sarm","mid_panto_ac_sarm"],
  },

}

trainPantoPosVehID = {
  "shonan_1" : {"0..4","default"},
  "shonan_2" : {"0..4","default"},
  "yamasuka_1" : {"0..4","default"},
  "yamasuka_2" : {"0..4","default"},
  "minobu_1" : {"0..4","default"},
  "niigata_1" : {"0..4","default"},
  "niigata_2" : {"0..4","default"},
  "niigata_3" : {"0..4","default"},
  "niigata_4" : {"0..4","default"},
  "yahiko_1" : {"0..4","default"},
  "yahiko_2" : {"0..4","default"},
  "nagano_1" : {"0..4","default"},
  "nagano_2" : {"0..4","default"},
  "fukuchiyama_1" : {"0..4","default"},
  "fukuchiyama_2" : {"0..4","default"},
  "setouchi_1" : {"0..4","default"},
  "hiroshima_1" : {"0..4","default"},
  "jrw_regional_1" : {"0..4","default"},
  "jrw_regional_2" : {"0..4","default"},
  "jrw_regional_3" : {"0..4","default"},
  "jrw_refurb_1" : {"0..4","default"},
  "jrw_refurb_2" : {"0..4","default"},
  "jrw_refurb_3" : {"0..4","default"},
  "shinano" : {"0..4","default"},
}

trainPantoPosChain = {
  "shonan_1": {
      "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "shonan_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "yamasuka_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "yamasuka_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "minobu_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "niigata_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "niigata_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "niigata_3": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "niigata_4": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "yahiko_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "yahiko_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "nagano_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "nagano_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "fukuchiyama_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "fukuchiyama_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "setouchi_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "hiroshima_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_regional_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_regional_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_regional_3": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_refurb_1": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_refurb_2": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "jrw_refurb_3": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  "shinano": {
    "0..4" :  {
        "0" : "mid_panto",
        "2" : "mid_panto",
        "default" : "mid",
        "%" : "4",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "3" : "mid_panto",
        "default" : "mid",
        "%" : "5",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)