import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "485"
trainIDNumber = "2048"
trainIDType = "emu_485"

#per train
trainLiveryList = [
    "jnr_inital",
    "jnr_late",
    ]

spriteList = [
    "front",
    "back",
    "back_panto",
    "mid",
    "mid_panto",
    "mid_gr",
    "mid_buffet",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "jnr_inital" : {"0..5","6","7","8","9","default"},
  "jnr_late" : {"0..5","6","7","8","9","default"},
}

trainPantoPosChain = {
  "jnr_inital": {
    "0..5" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_panto",
        "default" : "mid",
      }, 
    "6" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_buffet",
        "4" : "mid_panto",
        "default" : "mid",
      },
    "7" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_buffet",
        "5" : "mid_panto",
        "default" : "mid",
      },     
    "8" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",  
        "4" : "mid_buffet",
        "6" : "mid_panto",
        "default" : "mid",
      }, 
    "9" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",  
        "4" : "mid_buffet",
        "5" : "mid_panto",
        "7" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",  
        "4" : "mid_buffet",
        "5" : "mid_panto",
        "8" : "mid_panto",
        "default" : "mid",
        "%" : "12",
      }, 
    },

  "jnr_late": {
    "0..5" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_panto",
        "default" : "mid",
      }, 
    "6" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_buffet",
        "4" : "mid_panto",
        "default" : "mid",
      },
    "7" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_buffet",
        "5" : "mid_panto",
        "default" : "mid",
      },     
    "8" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",  
        "4" : "mid_buffet",
        "6" : "mid_panto",
        "default" : "mid",
      }, 
    "9" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",  
        "4" : "mid_buffet",
        "5" : "mid_panto",
        "7" : "mid_panto",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_panto",
        "2" : "mid_gr",
        "3" : "mid_gr",  
        "4" : "mid_buffet",
        "5" : "mid_panto",
        "8" : "mid_panto",
        "default" : "mid",
        "%" : "12",
      },
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)
