import JpyNML as JpyNML

#edit feilds
trainTypePrefix = "181"
trainIDNumber = "1516"
trainIDType = "dmu_181"

#per train
trainLiveryList = [
    "jnr",
    ]

spriteList = [
    "front",
    "back",
    "mid",
    "mid_gr",
    "mid_bft",
    ]

spriteYearOverride = {
}

trainPantoPosVehID = {
  "jnr" : {"0..3","4","5..8","default"},
}

trainPantoPosChain = {
  "jnr": {
    "0..3" :  {
        "default" : "mid",
      },
      "4" :  {
        "2" : "mid_gr",
        "default" : "mid",
      }, 
      "5..8" :  {
        "0" : "mid_gr",
        "1" : "mid_bft",
        "default" : "mid",
      }, 
      "6" :  {
        "0" : "mid_gr",
        "1" : "mid_gr",        
        "2" : "mid_bft",
        "default" : "mid",
      }, 
      "7" :  {
        "1" : "front82",        
        "2" : "mid_gr",
        "3" : "mid_bft",
        "default" : "mid",
      }, 
    "default" :  {
        "0" : "mid_gr",
        "1" : "mid_gr",        
        "2" : "mid_bft",
        "default" : "mid",
      }, 
    },
  }
  
#
#
#

JpyNML.Build_All(trainTypePrefix,trainIDNumber,trainIDType,trainLiveryList,spriteList,spriteYearOverride,trainPantoPosVehID,trainPantoPosChain)